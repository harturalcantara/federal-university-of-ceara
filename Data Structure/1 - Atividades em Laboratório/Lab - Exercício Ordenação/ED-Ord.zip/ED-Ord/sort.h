
void selectionSort(int n, int *v);
void selectionSortRec(int n, int *v);

void bubbleSort(int n, int *v);
void bubbleSortRec(int n, int *v);

void insertionSort(int n, int *v);
void insertionSortRec(int n, int *v);